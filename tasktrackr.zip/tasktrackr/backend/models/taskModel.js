const pool = require('../db');

exports.getAllTasks = async (search = '') => {
  const query = search
    ? `SELECT * FROM tasks WHERE title ILIKE $1 ORDER BY created_at DESC`
    : `SELECT * FROM tasks ORDER BY created_at DESC`;
  const values = search ? [`%${search}%`] : [];
  const { rows } = await pool.query(query, values);
  return rows;
};

exports.createTask = async ({ title, description, due_date }) => {
  const { rows } = await pool.query(
    `INSERT INTO tasks (title, description, due_date) VALUES ($1, $2, $3) RETURNING *`,
    [title, description, due_date]
  );
  return rows[0];
};

exports.updateTask = async (id, { title, description, due_date, status }) => {
  const { rows } = await pool.query(
    `UPDATE tasks SET title=$1, description=$2, due_date=$3, status=$4, updated_at=NOW() WHERE id=$5 RETURNING *`,
    [title, description, due_date, status, id]
  );
  return rows[0];
};

exports.deleteTask = async (id) => {
  await pool.query(`DELETE FROM tasks WHERE id = $1`, [id]);
};

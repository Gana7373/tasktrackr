import React from 'react';
import TaskPage from './pages/TaskPage';

function App() {
  return (
    <div className="p-4 max-w-xl mx-auto">
      <TaskPage />
    </div>
  );
}

export default App;

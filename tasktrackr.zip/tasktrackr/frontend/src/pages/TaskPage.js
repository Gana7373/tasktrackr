import React, { useState } from 'react';
import '../styles.css';

const initialTasks = [
  {
    id: 1,
    title: 'Complete Assignment',
    description: 'Finish the full-stack assignment for interview',
    due_date: '2025-05-14',
    status: 'pending',
  },
  {
    id: 2,
    title: 'Team Meeting',
    description: 'Project sync-up call with team',
    due_date: '2025-05-15',
    status: 'in progress',
  },
];

export default function TaskPage() {
  const [tasks, setTasks] = useState(initialTasks);
  const [form, setForm] = useState({ title: '', description: '', due_date: '' });

  const handleSubmit = (e) => {
    e.preventDefault();
    const newTask = {
      id: Date.now(),
      ...form,
      status: 'pending',
    };
    setTasks((prev) => [...prev, newTask]);
    setForm({ title: '', description: '', due_date: '' });
  };

  const handleDelete = (id) => {
    setTasks((prev) => prev.filter((task) => task.id !== id));
  };

  return (
    <div className="task-manager-container">
      <h1 className="task-manager-header">🌟 Task Manager</h1>

      <form onSubmit={handleSubmit} className="form-container">
        <input
          type="text"
          required
          placeholder="Enter task title"
          value={form.title}
          onChange={(e) => setForm({ ...form, title: e.target.value })}
        />
        <input
          type="text"
          required
          placeholder="Enter task description"
          value={form.description}
          onChange={(e) => setForm({ ...form, description: e.target.value })}
        />
        <input
          type="date"
          required
          value={form.due_date}
          onChange={(e) => setForm({ ...form, due_date: e.target.value })}
        />
        <button type="submit">➕ Add Task</button>
      </form>

      <div className="task-cards-container">
        {tasks.length === 0 ? (
          <p>No tasks added yet.</p>
        ) : (
          tasks.map((task) => (
            <div key={task.id} className="task-card">
              <h2>{task.title}</h2>
              <p>{task.description}</p>
              <p>
                <strong>Due:</strong> {new Date(task.due_date).toLocaleDateString()}
              </p>
              <span className={`task-status ${task.status}`}>
                {task.status}
              </span>
              <div
                onClick={() => handleDelete(task.id)}
                className="delete-btn"
              >
                🗑 Delete
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
